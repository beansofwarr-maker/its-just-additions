
SMODS.Back {
    key = 'stripes_and_colors',
    pos = { x = 9, y = 0 },
    config = {
        extra = {
            all_blinds_size0 = 1.25
        },
    },
    loc_txt = {
        name = 'Stripes And Colors',
        text = {
            [1] = '{C:attention}Divide every blind by 1.25{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling / 1.25
                return true
            end
        }))
    end
}