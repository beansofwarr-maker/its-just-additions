
SMODS.Back {
    key = 'golden_deck',
    pos = { x = 6, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Golden deck',
        text = {
            [1] = '{C:gold}Every card is gold{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_gold'])
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}