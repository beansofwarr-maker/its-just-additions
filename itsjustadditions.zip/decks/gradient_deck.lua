
SMODS.Back {
    key = 'gradient_deck',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            voucher_slots0 = 1
        },
    },
    loc_txt = {
        name = 'Gradient Deck',
        text = {
            [1] = '{C:green}1+{} Voucher slot and {C:blue}1+{} hand'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_voucher_limit(1)
                    return true
                end
            }))
        }
    end
}