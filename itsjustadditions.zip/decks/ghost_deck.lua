
SMODS.Back {
    key = 'ghost_deck',
    pos = { x = 7, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Ghost Deck',
        text = {
            [1] = 'Everything is ghost'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_itsjusta_ghost'])
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}