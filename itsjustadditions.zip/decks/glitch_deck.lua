
SMODS.Back {
    key = 'glitch_deck',
    pos = { x = 8, y = 0 },
    config = {
        extra = {
            odds = 5
        },
    },
    loc_txt = {
        name = 'Glitch Deck',
        text = {
            [1] = 'when you select this deck',
            [2] = 'you have a {C:green}1 in 5{} chance to',
            [3] = 'gain {C:blue}+1{} hand and {C:red}1+{} discard'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.setting_blind then
            local ante = G.GAME.win_ante - 1
            local int_part, frac_part = math.modf(ante)
            local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
            G.GAME.win_ante = rounded
        end
    end,
    apply = function(self, back)
        if SMODS.pseudorandom_probability(card, 'group_0_68758e65', 1, card.ability.extra.odds, 'j_itsjusta_glitch_deck', false) then
            G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
            G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
            
        end
    end
}