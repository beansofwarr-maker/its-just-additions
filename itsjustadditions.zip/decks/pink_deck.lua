
SMODS.Back {
    key = 'pink_deck',
    pos = { x = 1, y = 0 },
    config = {
    },
    loc_txt = {
        name = 'Pink Deck',
        text = {
            [1] = 'Makes every starting card {C:hearts}Hearts{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    assert(SMODS.change_base(v, 'Hearts'))
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}