
SMODS.Back {
    key = 'overclock_deck',
    pos = { x = 0, y = 1 },
    config = {
        extra = {
            booster_slots0 = 1,
            ante_value0 = 0
        },
    },
    loc_txt = {
        name = 'Overclock Deck',
        text = {
            [1] = '{C:blue}1+{} hand and {C:red}2+{} discards',
            [2] = '{C:attention}BUT{} every booster pack',
            [3] = 'increases the winner ante',
            [4] = '{C:attention}AND{} when deck is selected',
            [5] = 'set joker slots to 3'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.open_booster then
            local ante = G.GAME.win_ante + 1
            local int_part, frac_part = math.modf(ante)
            local rounded = int_part + (frac_part >= 0.5 and 1 or 0)
            G.GAME.win_ante = rounded
            return {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        SMODS.change_booster_limit(1)
                        return true
                    end
                }))
            }
        end
    end,
    apply = function(self, back)
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 2
        local mod = 0 - G.GAME.round_resets.ante
        G.E_MANAGER:add_event(Event({
            func = function()
                ease_ante(mod)
                G.GAME.round_resets.blind_ante = 0
                return true
            end,
        }))
        G.GAME.win_ante = 7
        G.GAME.starting_params.joker_slots = 3
    end
}