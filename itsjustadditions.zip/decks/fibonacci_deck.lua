
SMODS.Back {
    key = 'fibonacci_deck',
    pos = { x = 1, y = 1 },
    config = {
    },
    loc_txt = {
        name = 'Fibonacci Deck',
        text = {
            [1] = 'its all fibonacci'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.open_booster then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_fibonacci' })
                    if new_joker then
                        new_joker:set_edition("e_holo", true)
                    end
                    return true
                end
            }))
        end
    end,
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    local edition = pseudorandom_element({'e_foil','e_holo','e_polychrome','e_negative','e_itsjusta_laminated','e_itsjusta_flipped','e_itsjusta_monochrome','e_itsjusta_sepia'}, 'random edition')
                    v:set_edition(edition, true, true)
                    assert(SMODS.change_base(v, 'Clubs'))
                    assert(SMODS.change_base(v, nil, '5'))
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}