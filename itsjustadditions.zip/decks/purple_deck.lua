
SMODS.Back {
    key = 'purple_deck',
    pos = { x = 0, y = 0 },
    config = {
        consumables = {"c_fool","c_fool"},
    },
    loc_txt = {
        name = 'Purple Deck',
        text = {
            [1] = 'your set'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_lucky'])
                    v:set_seal("Red", true, true)
                    assert(SMODS.change_base(v, 'Diamonds'))
                    assert(SMODS.change_base(v, nil, '13'))
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
    end
}