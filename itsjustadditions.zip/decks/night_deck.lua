
SMODS.Back {
    key = 'night_deck',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            all_blinds_size0 = 1.5
        },
    },
    loc_txt = {
        name = 'Night Deck',
        text = {
            [1] = 'set {C:blue}hands{} and {C:red}discards{} to {C:hearts}2{}',
            [2] = '{C:attention}has extended abilities beyond',
            [3] = 'the deck description{}',
            [4] = '{C:inactive}(expected to break){}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * 1.5
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_itsjusta_nightdeckability' })
                    if new_joker then
                        new_joker:set_edition("e_negative", true)
                    end
                    G.GAME.joker_buffer = 0
                end
                return true
            end
        }))
    end
}