
SMODS.Booster {
    key = 'rare_booster_pack',
    loc_txt = {
        name = "Rare booster pack",
        text = {
            [1] = '{C:rare}Rare{} booster pack   . . , .'
        },
        group_name = "Rare booster pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 10,
    weight = 0.15,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
            set = "Joker",
            rarity = "Rare",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "itsjusta_rare_booster_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("6e2b2b"))
        ease_background_colour({ new_colour = HEX('6e2b2b'), special_colour = HEX("771515"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'legendary_booster_pack',
        loc_txt = {
            name = "Legendary booster pack",
            text = {
                [1] = '{C:legendary}Legendary{} booster pack . . . . . .'
            },
            group_name = "Legendary booster pack"
        },
        config = { extra = 3, choose = 1 },
        cost = 15,
        weight = 0.05,
        atlas = "CustomBoosters",
        pos = { x = 1, y = 0 },
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            return {
                set = "Joker",
                rarity = "Legendary",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "itsjusta_legendary_booster_pack"
            }
        end,
        ease_background_colour = function(self)
            ease_background_colour({ new_colour = HEX('b000ff') })
        end,
        particles = function(self)
            -- No particles for joker packs
            end,
        }
        
        
        SMODS.Booster {
            key = 'common_booster_pack',
            loc_txt = {
                name = "Common booster pack",
                text = {
                    [1] = '{C:common}Common{} booster pack . . . . .'
                },
                group_name = "Common booster pack"
            },
            config = { extra = 3, choose = 1 },
            cost = 3,
            atlas = "CustomBoosters",
            pos = { x = 2, y = 0 },
            discovered = true,
            loc_vars = function(self, info_queue, card)
                local cfg = (card and card.ability) or self.config
                return {
                    vars = { cfg.choose, cfg.extra }
                }
            end,
            create_card = function(self, card, i)
                return {
                    set = "Joker",
                    rarity = "Common",
                    area = G.pack_cards,
                    skip_materialize = true,
                    soulable = true,
                    key_append = "itsjusta_common_booster_pack"
                }
            end,
            ease_background_colour = function(self)
                ease_background_colour({ new_colour = HEX('1052e9') })
            end,
            particles = function(self)
                -- No particles for joker packs
                end,
            }
            
            
            SMODS.Booster {
                key = 'uncommon_booster_pack',
                loc_txt = {
                    name = "Uncommon booster pack",
                    text = {
                        [1] = '{C:uncommon}Uncommon{} booster pack . . . . . .'
                    },
                    group_name = "Uncommon booster pack"
                },
                config = { extra = 3, choose = 1 },
                cost = 6,
                weight = 0.75,
                atlas = "CustomBoosters",
                pos = { x = 3, y = 0 },
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    return {
                        set = "Joker",
                        rarity = "Uncommon",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "itsjusta_uncommon_booster_pack"
                    }
                end,
                particles = function(self)
                    -- No particles for joker packs
                    end,
                }
                
                
                SMODS.Booster {
                    key = 'voucher_booster_pack',
                    loc_txt = {
                        name = "Voucher booster pack",
                        text = {
                            [1] = 'self explanatory'
                        },
                        group_name = "Voucher booster pack"
                    },
                    config = { extra = 2, choose = 1 },
                    cost = 10,
                    weight = 1.15,
                    atlas = "CustomBoosters",
                    pos = { x = 4, y = 0 },
                    discovered = true,
                    loc_vars = function(self, info_queue, card)
                        local cfg = (card and card.ability) or self.config
                        return {
                            vars = { cfg.choose, cfg.extra }
                        }
                    end,
                    create_card = function(self, card, i)
                        return {
                            set = "Voucher",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true
                        }
                    end,
                    ease_background_colour = function(self)
                        ease_background_colour({ new_colour = HEX('a38947') })
                    end,
                    particles = function(self)
                        -- No particles for voucher packs
                        end,
                    }
                    
                    
                    SMODS.Booster {
                        key = 'mega_voucher_booster_pack',
                        loc_txt = {
                            name = "MEGA Voucher booster pack",
                            text = {
                                [1] = 'Voucher booster pack but you can choose',
                                [2] = '{C:attention}2{} instead of one'
                            },
                            group_name = "Voucher booster pack"
                        },
                        config = { extra = 5, choose = 2 },
                        cost = 18,
                        weight = 0.45,
                        atlas = "CustomBoosters",
                        pos = { x = 5, y = 0 },
                        discovered = true,
                        loc_vars = function(self, info_queue, card)
                            local cfg = (card and card.ability) or self.config
                            return {
                                vars = { cfg.choose, cfg.extra }
                            }
                        end,
                        create_card = function(self, card, i)
                            return {
                                set = "Voucher",
                                area = G.pack_cards,
                                skip_materialize = true,
                                soulable = true
                            }
                        end,
                        ease_background_colour = function(self)
                            ease_background_colour({ new_colour = HEX('a38947') })
                        end,
                        particles = function(self)
                            -- No particles for voucher packs
                            end,
                        }
                        
                        
                        SMODS.Booster {
                            key = 'rarity_pack',
                            loc_txt = {
                                name = "Rarity Pack",
                                text = {
                                    [1] = 'Contains 1 of every unmodded',
                                    [2] = 'rarity',
                                    [3] = '{C:common}Common{}, {C:uncommon}Uncommon{}, {C:rare}Rare{}',
                                    [4] = 'and {C:legendary}Legendary{}',
                                    [5] = 'and a very small chance to',
                                    [6] = 'have a {C:hearts}Mythical{}'
                                },
                                group_name = "itsjusta_boosters"
                            },
                            config = { extra = 4, choose = 1 },
                            cost = 16,
                            weight = 0.2,
                            atlas = "CustomBoosters",
                            pos = { x = 6, y = 0 },
                            discovered = true,
                            loc_vars = function(self, info_queue, card)
                                local cfg = (card and card.ability) or self.config
                                return {
                                    vars = { cfg.choose, cfg.extra }
                                }
                            end,
                            create_card = function(self, card, i)
                                local weights = {
                                    5,
                                    5,
                                    5,
                                    5,
                                    0.05
                                }
                                local total_weight = 0
                                for _, weight in ipairs(weights) do
                                    total_weight = total_weight + weight
                                end
                                local random_value = pseudorandom('itsjusta_rarity_pack_card') * total_weight
                                local cumulative_weight = 0
                                local selected_index = 1
                                for j, weight in ipairs(weights) do
                                    cumulative_weight = cumulative_weight + weight
                                    if random_value <= cumulative_weight then
                                        selected_index = j
                                        break
                                    end
                                end
                                if selected_index == 1 then
                                    return {
                                        set = "Joker",
                                        rarity = "Common",
                                        area = G.pack_cards,
                                        skip_materialize = true,
                                        soulable = true,
                                        key_append = "itsjusta_rarity_pack"
                                    }
                                elseif selected_index == 2 then
                                    return {
                                        set = "Joker",
                                        rarity = "Uncommon",
                                        area = G.pack_cards,
                                        skip_materialize = true,
                                        soulable = true,
                                        key_append = "itsjusta_rarity_pack"
                                    }
                                elseif selected_index == 3 then
                                    return {
                                        set = "Joker",
                                        rarity = "Rare",
                                        area = G.pack_cards,
                                        skip_materialize = true,
                                        soulable = true,
                                        key_append = "itsjusta_rarity_pack"
                                    }
                                elseif selected_index == 4 then
                                    return {
                                        set = "Joker",
                                        rarity = "Legendary",
                                        area = G.pack_cards,
                                        skip_materialize = true,
                                        soulable = true,
                                        key_append = "itsjusta_rarity_pack"
                                    }
                                elseif selected_index == 5 then
                                    return {
                                        set = "Joker",
                                        rarity = "itsjusta_mythical",
                                        area = G.pack_cards,
                                        skip_materialize = true,
                                        soulable = true,
                                        key_append = "itsjusta_rarity_pack"
                                    }
                                end
                            end,
                            particles = function(self)
                                -- No particles for joker packs
                                end,
                            }
                            