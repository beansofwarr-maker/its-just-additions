
SMODS.Shader({ key = 'monochrome', path = 'monochrome.fs' })

SMODS.Edition {
    key = 'monochrome',
    shader = 'monochrome',
    in_shop = false,
    weight = 1,
    extra_cost = 1,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Monochrome',
        label = 'Monochrome',
        text = {
            [1] = 'whos ready for gaster?'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) then
            error("EasternFarmer Was Here")
        end
    end
}