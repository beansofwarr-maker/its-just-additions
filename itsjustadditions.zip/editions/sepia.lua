
SMODS.Shader({ key = 'sepia', path = 'sepia.fs' })

SMODS.Edition {
    key = 'sepia',
    shader = 'sepia',
    in_shop = false,
    apply_to_float = false,
    badge_colour = HEX('383838'),
    sound = { sound = "explosion1", per = 1.2, vol = 0.4 },
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Sepia',
        label = 'Sepia',
        text = {
            [1] = '{X:red,C:white}X0.4{} Mult'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
}