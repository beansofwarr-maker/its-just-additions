
SMODS.Shader({ key = 'laminated', path = 'laminated.fs' })

SMODS.Edition {
    key = 'laminated',
    shader = 'laminated',
    config = {
        extra = {
            xmult0 = 1.5,
            odds = 18
        }
    },
    in_shop = false,
    extra_cost = 2,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Laminated',
        label = 'Laminated',
        text = {
            [1] = '{X:red,C:white}X1.5{} Mult but a {C:hearts}1 in 18{}',
            [2] = 'chance to destroy itself'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) then
            return {
                Xmult = 1.5
            }
        end
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) then
            if SMODS.pseudorandom_probability(card, 'group_0_15c751a8', 1, card.ability.extra.odds, 'j_itsjusta_laminated', false) then
                local destructable_jokers = {}
                for i, joker in ipairs(G.jokers.cards) do
                    if not joker.ability.eternal and not joker.getting_sliced then
                        table.insert(destructable_jokers, joker)
                    end
                end
                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker_enhanced')) or nil
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                end
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed Joker!", colour = G.C.RED})
            end
        end
    end
}