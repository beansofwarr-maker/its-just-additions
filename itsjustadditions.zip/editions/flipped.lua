
SMODS.Shader({ key = 'flipped', path = 'flipped.fs' })

SMODS.Edition {
    key = 'flipped',
    shader = 'flipped',
    config = {
        extra = {
            odds = 4,
            xmult0 = 2,
            odds = 300,
            echips0 = 100,
            echips = 100,
            dollars0 = 6,
            xchips0 = 1.5
        }
    },
    in_shop = false,
    weight = 2.5,
    extra_cost = 4,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Flipped',
        label = 'Flipped',
        text = {
            [1] = 'its flipped so you dont know'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) then
            if SMODS.pseudorandom_probability(card, 'group_0_4cf259bb', 1, card.ability.extra.odds, 'j_itsjusta_flipped', false) then
                SMODS.calculate_effect({Xmult = 2}, card)
            end
        end
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) then
            if SMODS.pseudorandom_probability(card, 'group_0_f923a410', 1, card.ability.extra.odds2, 'j_itsjusta_flipped', false) then
                SMODS.calculate_effect({e_chips = 100}, card)
                SMODS.calculate_effect({e_chips = 100}, card)
            end
        end
        if (context.pre_joker or (context.main_scoring and context.cardarea == G.play)) then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 6
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(6), colour = G.C.MONEY})
                    return true
                end,
                extra = {
                    x_chips = 1.5,
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end
}