
SMODS.Voucher {
    key = 'voucher_of_pain_and_misery',
    pos = { x = 0, y = 0 },
    config = { 
        extra = {
            all_blinds_size0 = 2
        } 
    },
    loc_txt = {
        name = 'Voucher of pain and misery',
        text = {
            [1] = 'divides the blinds by 2',
            [2] = 'bottom text'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 5,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling / 2
                return true
            end
        }))
    end
}