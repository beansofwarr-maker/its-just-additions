
SMODS.Voucher {
    key = 'joker_forge',
    pos = { x = 4, y = 0 },
    config = { 
        extra = {
            booster_slots0 = 1
        } 
    },
    loc_txt = {
        name = 'Joker Forge',
        text = {
            [1] = '{C:green}1+{} booster slots'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    SMODS.change_booster_limit(1)
                    return true
                end
            }))
        }
    end
}