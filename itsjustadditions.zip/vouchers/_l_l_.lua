
SMODS.Voucher {
    key = '_l_l_',
    pos = { x = 2, y = 0 },
    config = { 
        extra = {
            dollars0 = 10,
            hands0 = 1,
            discards0 = 1,
            repetitions = 1
        } 
    },
    loc_txt = {
        name = '? l ? l ?',
        text = {
            [1] = '? l ? l ?'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v__'},
    atlas = 'CustomVouchers',
    redeem = function(self, card)
        G.GAME.round_resets.hands = G.GAME.round_resets.hands + 1
        ease_hands_played(1)
        G.GAME.round_resets.discards = G.GAME.round_resets.discards + 1
        ease_discard(1)
        return {
            
            func = function()
                
                local current_dollars = G.GAME.dollars
                local target_dollars = G.GAME.dollars + 10
                local dollar_value = target_dollars - current_dollars
                ease_dollars(dollar_value, true)
                card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(10), colour = G.C.MONEY})
                return true
            end,
            extra = {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.round_resets.reroll_cost = G.GAME.round_resets.reroll_cost - 1
                        G.GAME.current_round.reroll_cost = math.max(0,
                        G.GAME.current_round.reroll_cost - 1)
                        return true
                    end
                }))
                ,
                colour = G.C.BLUE,
                extra = {
                    
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            G.consumeables.config.card_limit = G.consumeables.config.card_limit + 1
                            return true
                        end
                    }))
                    ,
                    colour = G.C.BLUE,
                    extra = {
                        
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                G.jokers.config.card_limit = G.jokers.config.card_limit + 1
                                return true
                            end
                        }))
                        ,
                        colour = G.C.DARK_EDITION
                    }
                }
            }
            ,
            func = function()
                for i = 1, 1 do
                    SMODS.calculate_effect({func = function()
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                local tag = Tag("tag_double")
                                if tag.name == "Orbital Tag" then
                                    local _poker_hands = {}
                                    for k, v in pairs(G.GAME.hands) do
                                        if v.visible then
                                            _poker_hands[#_poker_hands + 1] = k
                                        end
                                    end
                                    tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                                end
                                tag:set_ability()
                                add_tag(tag)
                                play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                                return true
                            end
                        }))
                        return true
                    end}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
                end
                return true
            end
        }
    end
}