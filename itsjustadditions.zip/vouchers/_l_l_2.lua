
SMODS.Voucher {
    key = '_l_l_2',
    pos = { x = 3, y = 0 },
    loc_txt = {
        name = '? ? l ? ? l ? / ?',
        text = {
            [1] = '{C:blue}? ? l ? ? l ? / ?{}'
        },
        unlock = {
            [1] = 'Unlocked by default.'
        }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v__l_l_'},
    atlas = 'CustomVouchers',
    
}