
SMODS.Joker{ --Geometry Dash
    key = "geometrydash",
    config = {
        extra = {
            xmult0 = 2.5,
            xchips0 = 3,
            xmult = 5,
            xchips = 6,
            xmult2 = 7.5,
            xchips2 = 9,
            xmult3 = 10,
            xchips3 = 12,
            xmult4 = 12.5,
            xchips4 = 15,
            xmult5 = 15,
            xchips5 = 18,
            xmult6 = 17.5,
            xchips6 = 21,
            xmult7 = 20,
            xchips7 = 25,
            odds = 4,
            xmult8 = 5,
            xchips8 = 7.5,
            sell_value0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Geometry Dash',
        ['text'] = {
            [1] = '{X:red,C:white}X2.5{} Mult for every joker you have',
            [2] = 'and {X:blue,C:white}X3{} Chips every joker  you have',
            [3] = 'and {C:money}1$+{} sell value every blind',
            [4] = '{C:inactive}(jokers cap at 7){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 21,
    rarity = "itsjusta_mythical",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' 
            or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_itsjusta_geometrydash') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(#G.jokers.cards) == to_big(1) then
                return {
                    Xmult = 2.5,
                    extra = {
                        x_chips = 3,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) == to_big(2) then
                return {
                    Xmult = 5,
                    extra = {
                        x_chips = 6,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) == to_big(3) then
                return {
                    Xmult = 7.5,
                    extra = {
                        x_chips = 9,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) == to_big(4) then
                return {
                    Xmult = 10,
                    extra = {
                        x_chips = 12,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) == to_big(5) then
                return {
                    Xmult = 12.5,
                    extra = {
                        x_chips = 15,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) == to_big(6) then
                return {
                    Xmult = 15,
                    extra = {
                        x_chips = 18,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) == to_big(7) then
                return {
                    Xmult = 17.5,
                    extra = {
                        x_chips = 21,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) > to_big(7) then
                return {
                    Xmult = 20,
                    extra = {
                        x_chips = 25,
                        colour = G.C.DARK_EDITION
                    }
                }
            elseif to_big(#G.jokers.cards) > to_big(7) then
                if SMODS.pseudorandom_probability(card, 'group_0_9fa96a1a', 1, card.ability.extra.odds, 'j_itsjusta_geometrydash', false) then
                    SMODS.calculate_effect({Xmult = 5}, card)
                    SMODS.calculate_effect({x_chips = 7.5}, card)
                end
            end
        end
        if context.setting_blind  then
            return {
                func = function()local my_pos = nil
                    for i = 1, #G.jokers.cards do
                        if G.jokers.cards[i] == card then
                            my_pos = i
                            break
                        end
                    end
                    local target_card = G.jokers.cards[my_pos]
                    target_card.ability.extra_value = (card.ability.extra_value or 0) + 1
                    target_card:set_cost()
                    return true
                end,
                message = "+"..tostring(1).." Sell Value"
            }
        end
    end
}