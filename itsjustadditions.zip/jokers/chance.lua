
SMODS.Joker{ --CHANCE
    key = "chance",
    config = {
        extra = {
            odds = 10,
            xmult0 = 1.5,
            xchips0 = 1.5,
            echips0 = 2,
            hypermult_n0 = 1.1,
            hypermult_arrows0 = 1,
            hyperchips_n0 = 1.1,
            hyperchips_arrows0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'CHANCE',
        ['text'] = {
            [1] = 'its a 1 in 10 every card',
            [2] = 'that scores'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_itsjusta_chance') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_ffeb1600', 1, card.ability.extra.odds, 'j_itsjusta_chance', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                    SMODS.calculate_effect({x_chips = 1.5}, card)
                    SMODS.calculate_effect({e_chips = 2}, card)
                    SMODS.calculate_effect({hypermult = {
                        1,
                        1.1
                    }}, card)
                    SMODS.calculate_effect({hyperchips = {
                        1,
                        1.1
                    }}, card)
                end
            end
        end
    end
}