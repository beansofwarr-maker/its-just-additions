
SMODS.Joker{ --banana monkey
    key = "bananamonkey",
    config = {
        extra = {
            mult0 = 15,
            mult = 2
        }
    },
    loc_txt = {
        ['name'] = 'banana monkey',
        ['text'] = {
            [1] = 'be so for real dont say it',
            [2] = 'im not green im a Mult',
            [3] = 'monkey'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = 15
            }
        end
        if context.individual and context.cardarea == G.play  then
            return {
                mult = 2
            }
        end
    end
}