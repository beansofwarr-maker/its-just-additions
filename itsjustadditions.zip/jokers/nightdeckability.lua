
SMODS.Joker{ --Night Deck ability
    key = "nightdeckability",
    config = {
        extra = {
            echips0 = 1.05,
            chips0 = 30,
            mult0 = 5,
            mult = 5,
            chips = 15
        }
    },
    loc_txt = {
        ['name'] = 'Night Deck ability',
        ['text'] = {
            [1] = 'every time a card is scored',
            [2] = 'gain {C:blue}15+ Chips{}',
            [3] = '{C:red}2+ Mult{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 4,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rif' and args.source ~= 'sou' 
            or args.source == 'rta' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                e_chips = 1.05,
                extra = {
                    chips = 30,
                    colour = G.C.CHIPS,
                    extra = {
                        mult = 5
                    }
                }
            }
        end
        if context.individual and context.cardarea == G.play  then
            return {
                mult = 5,
                extra = {
                    chips = 15,
                    colour = G.C.CHIPS
                }
            }
        end
    end
}