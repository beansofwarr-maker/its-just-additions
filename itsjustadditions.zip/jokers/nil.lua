
SMODS.Joker{ --Nil
    key = "nil",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Nil',
        ['text'] = {
            [1] = 'Does nothing?'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_unknownd_jokers"] = true }
}