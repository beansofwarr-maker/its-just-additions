
SMODS.Joker{ --Glitch
    key = "glitch",
    config = {
        extra = {
            aswwd = 1,
            xmult0 = 5.1415296,
            sell_value0 = 4,
            blind_size0 = 1.05,
            sell_value = 6,
            sell_value2 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Glitch',
        ['text'] = {
            [1] = '{C:hearts}&*^%*(^%&^(%#^(#%$&*&(^*$&{}',
                [2] = '{C:clubs}^#^&&*@^^&%$&%^(&*^@$&*({}',
                    [3] = '{C:diamonds}*^%$^&%@*$^%@&*$^%$@&^%*${}',
                    [4] = '{C:spades}#^&(%&*^($(@(@#%@^$@*$^@({}'
                    },
                    ['unlock'] = {
                        [1] = 'Unlocked by default.'
                    }
                },
                pos = {
                    x = 5,
                    y = 1
                },
                display_size = {
                    w = 71 * 1, 
                    h = 95 * 1
                },
                cost = 21,
                rarity = "itsjusta_exotic",
                blueprint_compat = true,
                eternal_compat = true,
                perishable_compat = true,
                unlocked = true,
                discovered = false,
                atlas = 'CustomJokers',
                pools = { ["itsjusta_itsjusta_jokers"] = true },
                in_pool = function(self, args)
                    return (
                        not args 
                        or args.source ~= 'buf' and args.source ~= 'jud' 
                        or args.source == 'sho' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
                    )
                    and true
                end,
                
                loc_vars = function(self, info_queue, card)
                    
                    return {vars = {card.ability.extra.aswwd}}
                end,
                
                calculate = function(self, card, context)
                    if context.individual and context.cardarea == G.play  then
                        return {
                            Xmult = 5.1415296
                        }
                    end
                    if context.setting_blind  then
                        return {
                            func = function()
                                for i, target_card in ipairs(G.jokers.cards) do
                                    if target_card.set_cost then
                                        target_card.ability.extra_value = (card.ability.extra_value or 0) + 4
                                        target_card:set_cost()
                                    end
                                end
                                return true
                            end,
                            message = "All Jokers +"..tostring(4).." Sell Value",
                            extra = {
                                
                                func = function()
                                    if G.GAME.blind.in_blind then
                                        
                                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "/"..tostring(1.05).." Blind Size", colour = G.C.GREEN})
                                        G.GAME.blind.chips = G.GAME.blind.chips / 1.05
                                        G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                                        G.HUD_blind:recalculate()
                                        return true
                                    end
                                end,
                                colour = G.C.GREEN
                            }
                        }
                    end
                    if context.selling_card  then
                        return {
                            func = function()local my_pos = nil
                                for i = 1, #G.jokers.cards do
                                    if G.jokers.cards[i] == card then
                                        my_pos = i
                                        break
                                    end
                                end
                                local target_card = G.jokers.cards[my_pos]
                                target_card.ability.extra_value = (card.ability.extra_value or 0) + 6
                                target_card:set_cost()
                                return true
                            end,
                            message = "+"..tostring(6).." Sell Value",
                            extra = {
                                func = function()
                                    for _, area in ipairs({ G.jokers, G.consumeables }) do
                                        for i, target_card in ipairs(area.cards) do
                                            if target_card.set_cost then
                                                target_card.ability.extra_value = (card.ability.extra_value or 0) + 3
                                                target_card:set_cost()
                                            end
                                        end
                                    end
                                    return true
                                end,
                                message = "All cards +"..tostring(3).." Sell Value",
                                colour = G.C.MONEY
                            }
                        }
                    end
                    if context.reroll_shop  then
                        return {
                            func = function()
                                
                                local created_joker = true
                                G.E_MANAGER:add_event(Event({
                                    func = function()
                                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_itsjusta__50mult' })
                                        if joker_card then
                                            joker_card:set_edition("e_negative", true)
                                            
                                        end
                                        
                                        return true
                                    end
                                }))
                                
                                if created_joker then
                                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
                                end
                                return true
                            end
                        }
                    end
                end
            }