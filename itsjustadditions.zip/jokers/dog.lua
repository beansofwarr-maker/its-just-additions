
SMODS.Joker{ --Dog
    key = "dog",
    config = {
        extra = {
            odds = 2,
            xmult0 = 1.5,
            odds2 = 3,
            xmult = 1.5,
            odds3 = 5,
            xmult2 = 1.5,
            odds4 = 8,
            xmult3 = 1.5,
            odds5 = 12,
            xmult4 = 1.5,
            odds6 = 17,
            xmult5 = 1.5,
            odds7 = 23,
            xmult6 = 2,
            odds8 = 30,
            xmult7 = 2,
            odds9 = 38,
            xmult8 = 2.5,
            odds10 = 47,
            xmult9 = 3,
            odds11 = 57,
            xmult10 = 3,
            odds12 = 68,
            xmult11 = 5
        }
    },
    loc_txt = {
        ['name'] = 'Dog',
        ['text'] = {
            [1] = 'Dog'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_itsjusta_dog')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_itsjusta_dog')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_itsjusta_dog')
        local new_numerator4, new_denominator4 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds4, 'j_itsjusta_dog')
        local new_numerator5, new_denominator5 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds5, 'j_itsjusta_dog')
        local new_numerator6, new_denominator6 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds6, 'j_itsjusta_dog')
        local new_numerator7, new_denominator7 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds7, 'j_itsjusta_dog')
        local new_numerator8, new_denominator8 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds8, 'j_itsjusta_dog')
        local new_numerator9, new_denominator9 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds9, 'j_itsjusta_dog')
        local new_numerator10, new_denominator10 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds10, 'j_itsjusta_dog')
        local new_numerator11, new_denominator11 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds11, 'j_itsjusta_dog')
        local new_numerator12, new_denominator12 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds12, 'j_itsjusta_dog')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3, new_numerator4, new_denominator4, new_numerator5, new_denominator5, new_numerator6, new_denominator6, new_numerator7, new_denominator7, new_numerator8, new_denominator8, new_numerator9, new_denominator9, new_numerator10, new_denominator10, new_numerator11, new_denominator11, new_numerator12, new_denominator12}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_d967b755', 1, card.ability.extra.odds, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_b9320391', 1, card.ability.extra.odds2, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_c7556fe1', 1, card.ability.extra.odds3, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_9a7ed6df', 1, card.ability.extra.odds4, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_f9569370', 1, card.ability.extra.odds5, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_351f491a', 1, card.ability.extra.odds6, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_ea8d8dcf', 1, card.ability.extra.odds7, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_5ac7839f', 1, card.ability.extra.odds8, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 2}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_02a4c167', 1, card.ability.extra.odds9, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 2.5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_b7125140', 1, card.ability.extra.odds10, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 3}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_3959268c', 1, card.ability.extra.odds11, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 3}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_bf415e19', 1, card.ability.extra.odds12, 'j_itsjusta_dog', false) then
                    SMODS.calculate_effect({Xmult = 5}, card)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "bark!", colour = G.C.WHITE})
                end
            end
        end
    end
}