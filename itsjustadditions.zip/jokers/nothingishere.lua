
SMODS.Joker{ --Nothing is here
    key = "nothingishere",
    config = {
        extra = {
            xmult0 = 1.5,
            odds = 1200
        }
    },
    loc_txt = {
        ['name'] = 'Nothing is here',
        ['text'] = {
            [1] = '{X:red,C:white}X1.5{} Mult but {C:green}1 in 1,200{}',
            [2] = 'to {C:hearts}Destroy{} itself'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_itsjusta_nothingishere') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 1.5
            }
        end
        if context.starting_shop  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_0c09074f', 1, card.ability.extra.odds, 'j_itsjusta_nothingishere', false) then
                    SMODS.calculate_effect({func = function()
                        local target_joker = card
                        
                        if target_joker then
                            if target_joker.ability.eternal then
                                target_joker.ability.eternal = nil
                            end
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end}, card)
                end
            end
        end
    end
}