
SMODS.Joker{ --ERROR
    key = "error",
    config = {
        extra = {
            xmult0 = 1.1,
            repetitions0 = 5
        }
    },
    loc_txt = {
        ['name'] = 'ERROR',
        ['text'] = {
            [1] = 'Retriggers everything 5 times',
            [2] = 'and like {X:red,C:white}X1.1{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_unknownd_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' 
            or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = 1.1
            }
        end
        if context.repetition and context.cardarea == G.play  then
            return {
                repetitions = 5,
                message = localize('k_again_ex')
            }
        end
    end
}