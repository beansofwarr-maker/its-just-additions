
SMODS.Joker{ --I have no ideas
    key = "ihavenoideas",
    config = {
        extra = {
            xmult0 = 5,
            xchips0 = 10,
            repetitions0 = 10
        }
    },
    loc_txt = {
        ['name'] = 'I have no ideas',
        ['text'] = {
            [1] = '{X:red,C:white}X5{} Mult, retriggers cards 10 times and {X:blue,C:white}X10{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            return {
                Xmult = 5,
                extra = {
                    x_chips = 10,
                    colour = G.C.DARK_EDITION,
                    extra = {
                        repetitions = 10,
                        message = localize('k_again_ex'),
                        colour = G.C.RED
                    }
                }
            }
        end
    end
}