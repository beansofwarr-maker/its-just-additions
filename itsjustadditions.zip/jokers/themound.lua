
SMODS.Joker{ --The Mound
    key = "themound",
    config = {
        extra = {
            joker_slots0 = 2,
            hands0 = 2
        }
    },
    loc_txt = {
        ['name'] = 'The Mound',
        ['text'] = {
            [1] = 'everytime a boss blind is defeated gain 2 joker slots and lose 2 hands'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_unknownd_jokers"] = true },
    
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(2).." Joker Slot", colour = G.C.DARK_EDITION})
                    G.jokers.config.card_limit = G.jokers.config.card_limit + 2
                    return true
                end,
                extra = {
                    
                    func = function()
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(2).." Hands", colour = G.C.RED})
                        
                        G.GAME.round_resets.hands = G.GAME.round_resets.hands - 2
                        ease_hands_played(-2)
                        
                        return true
                    end,
                    colour = G.C.GREEN
                }
            }
        end
    end
}