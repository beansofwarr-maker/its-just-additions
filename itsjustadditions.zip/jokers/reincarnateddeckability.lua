
SMODS.Joker{ --Reincarnated deck ability
    key = "reincarnateddeckability",
    config = {
        extra = {
            mult0 = -2,
            mult = -8,
            mult2 = -32,
            mult3 = -88,
            mult4 = -99,
            mult5 = -150,
            mult6 = -200,
            mult7 = -400,
            mult8 = -350
        }
    },
    loc_txt = {
        ['name'] = 'Reincarnated deck ability',
        ['text'] = {
            [1] = 'for extended usages because',
            [2] = 'of joker forge\'s limitations'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = 4,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["itsjusta_itsjusta_jokers"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'rif' and args.source ~= 'sou' 
            or args.source == 'rta' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
        card:set_edition("e_negative", true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if to_big(G.GAME.round_resets.ante) == to_big(1) then
                return {
                    mult = -2
                }
            elseif to_big(G.GAME.round_resets.ante) == to_big(2) then
                return {
                    mult = -8
                }
            elseif to_big(G.GAME.round_resets.ante) == to_big(3) then
                return {
                    mult = -32
                }
            elseif to_big(G.GAME.round_resets.ante) == to_big(4) then
                return {
                    mult = -88
                }
            elseif to_big(G.GAME.round_resets.ante) == to_big(5) then
                return {
                    mult = -99
                }
            elseif to_big(G.GAME.round_resets.ante) == to_big(6) then
                return {
                    mult = -150
                }
            elseif to_big(G.GAME.round_resets.ante) == to_big(7) then
                return {
                    mult = -200
                }
            elseif to_big(G.GAME.round_resets.ante) == to_big(8) then
                return {
                    mult = -400
                }
            elseif to_big(G.GAME.round_resets.ante) > to_big(8) then
                return {
                    mult = -350
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
        end
    end
}