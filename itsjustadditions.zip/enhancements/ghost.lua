
SMODS.Enhancement {
    key = 'ghost',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xmult0 = 1.1,
            xchips0 = 1.1
        }
    },
    loc_txt = {
        name = 'Ghost',
        text = {
            [1] = '{X:red,C:white}X1.1{} Mult and {X:blue,C:white}X1.1{} Chips'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 19,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 1.1,
                extra = {
                    x_chips = 1.1,
                    colour = G.C.DARK_EDITION
                }
            }
        end
    end
}