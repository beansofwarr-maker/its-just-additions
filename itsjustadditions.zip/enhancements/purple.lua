
SMODS.Enhancement {
    key = 'purple',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            xmult0 = 60,
            odds = 1.05
        }
    },
    loc_txt = {
        name = '- Purple -',
        text = {
            [1] = '{X:red,C:white}X60{} Mult but every time this card',
            [2] = 'is used',
            [3] = '--------------------',
            [4] = '{C:hearts}1 in 1.05{} chance to',
            [5] = 'destroy itself'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0.5,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 60
            }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            if SMODS.pseudorandom_probability(card, 'group_0_732334da', 1, card.ability.extra.odds, 'j_itsjusta_purple', false) then
                context.other_card.should_destroy = true
                card.should_destroy = true
                
            end
        end
    end
}