
SMODS.Enhancement {
    key = 'goldglass',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            dollars0 = 3,
            xmult0 = 2,
            odds = 4
        }
    },
    loc_txt = {
        name = 'Gold Glass',
        text = {
            [1] = 'has the effects of {C:attention}both{}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 1,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.cardarea == G.hand and context.main_scoring then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 3
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(3), colour = G.C.MONEY})
                    return true
                end
            }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            return {
                Xmult = 2
                ,
                func = function()
                    if SMODS.pseudorandom_probability(card, 'group_0_6efde151', 1, card.ability.extra.odds, 'j_itsjusta_goldglass', false) then
                        context.other_card.should_destroy = true
                        card.should_destroy = true
                        
                    end
                    return true
                end
            }
        end
    end
}