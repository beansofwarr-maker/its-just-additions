
SMODS.Enhancement {
    key = 'halfsquares',
    pos = { x = 1, y = 0 },
    config = {
        mult = 4,
        extra = {
            xmult0 = 1.000001
        }
    },
    loc_txt = {
        name = 'Half Squares',
        text = {
            [1] = '{C:red}10+{} Mult',
            [2] = '{C:green}Always scores{}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 2,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 1.000001
            }
        end
    end
}