SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomVouchers", 
    path = "CustomVouchers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end
-- this function is used to load everything within a folder.-- Jokerforge doesnt use it because it doesnt make loading order easy
local function load_folder(path)
    local files = NFS.getDirectoryItemsInfo(mod_path .. "/" .. path)
    for i = 1, #files do
        local file_name = files[i].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file(path .. file_name))()
        end
    end
end
-- load the jokers
if true then
    assert(SMODS.load_file("jokers/biipwah.lua"))()
    assert(SMODS.load_file("jokers/crumbled.lua"))()
    assert(SMODS.load_file("jokers/themound.lua"))()
    assert(SMODS.load_file("jokers/nil.lua"))()
    assert(SMODS.load_file("jokers/error.lua"))()
    assert(SMODS.load_file("jokers/cursed.lua"))()
    assert(SMODS.load_file("jokers/bananamonkey.lua"))()
    assert(SMODS.load_file("jokers/nightdeckability.lua"))()
    assert(SMODS.load_file("jokers/reincarnateddeckability.lua"))()
    assert(SMODS.load_file("jokers/ihavenoideas.lua"))()
    assert(SMODS.load_file("jokers/oshainspector.lua"))()
    assert(SMODS.load_file("jokers/chance.lua"))()
    assert(SMODS.load_file("jokers/stars.lua"))()
    assert(SMODS.load_file("jokers/flower.lua"))()
    assert(SMODS.load_file("jokers/rage.lua"))()
    assert(SMODS.load_file("jokers/glitch.lua"))()
    assert(SMODS.load_file("jokers/_50mult.lua"))()
    assert(SMODS.load_file("jokers/geometrydash.lua"))()
    assert(SMODS.load_file("jokers/codingattempt.lua"))()
    assert(SMODS.load_file("jokers/nothingishere.lua"))()
    assert(SMODS.load_file("jokers/dog.lua"))()
end
--load the sets
assert(SMODS.load_file("consumables/sets.lua"))()
-- load the enhancements
if true then
    assert(SMODS.load_file("enhancements/ghost.lua"))()
    assert(SMODS.load_file("enhancements/halfsquares.lua"))()
    assert(SMODS.load_file("enhancements/purple.lua"))()
    assert(SMODS.load_file("enhancements/goldglass.lua"))()
end

-- load the seals
if true then
    assert(SMODS.load_file("seals/glitch.lua"))()
    assert(SMODS.load_file("seals/stoneseal.lua"))()
    assert(SMODS.load_file("seals/squished.lua"))()
    assert(SMODS.load_file("seals/jokerseal.lua"))()
end

-- load the editions
if true then
    assert(SMODS.load_file("editions/laminated.lua"))()
    assert(SMODS.load_file("editions/flipped.lua"))()
    assert(SMODS.load_file("editions/monochrome.lua"))()
    assert(SMODS.load_file("editions/sepia.lua"))()
end

-- load the vouchers
if true then
    assert(SMODS.load_file("vouchers/voucher_of_pain_and_misery.lua"))()
    assert(SMODS.load_file("vouchers/_.lua"))()
    assert(SMODS.load_file("vouchers/_l_l_.lua"))()
    assert(SMODS.load_file("vouchers/_l_l_2.lua"))()
    assert(SMODS.load_file("vouchers/joker_forge.lua"))()
end

-- load the decks
if true then
    assert(SMODS.load_file("decks/purple_deck.lua"))()
    assert(SMODS.load_file("decks/pink_deck.lua"))()
    assert(SMODS.load_file("decks/gradient_deck.lua"))()
    assert(SMODS.load_file("decks/night_deck.lua"))()
    assert(SMODS.load_file("decks/reincarnated_deck.lua"))()
    assert(SMODS.load_file("decks/glass_deck.lua"))()
    assert(SMODS.load_file("decks/golden_deck.lua"))()
    assert(SMODS.load_file("decks/ghost_deck.lua"))()
    assert(SMODS.load_file("decks/glitch_deck.lua"))()
    assert(SMODS.load_file("decks/stripes_and_colors.lua"))()
    assert(SMODS.load_file("decks/overclock_deck.lua"))()
    assert(SMODS.load_file("decks/fibonacci_deck.lua"))()
end



assert(SMODS.load_file("rarities.lua"))()


-- load boosters
assert(SMODS.load_file("boosters.lua"))()
--load sounds
assert(SMODS.load_file("sounds.lua"))()
SMODS.ObjectType({
    key = "itsjusta_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "itsjusta_customjo_jokers",
    cards = {
        ["j_itsjusta_biipwah"] = true
    },
})

SMODS.ObjectType({
    key = "itsjusta_unknownd_jokers",
    cards = {
        ["j_itsjusta_crumbled"] = true,
        ["j_itsjusta_themound"] = true,
        ["j_itsjusta_nil"] = true,
        ["j_itsjusta_error"] = true
    },
})

SMODS.ObjectType({
    key = "itsjusta_itsjusta_jokers",
    cards = {
        ["j_itsjusta_cursed"] = true,
        ["j_itsjusta_bananamonkey"] = true,
        ["j_itsjusta_nightdeckability"] = true,
        ["j_itsjusta_reincarnateddeckability"] = true,
        ["j_itsjusta_ihavenoideas"] = true,
        ["j_itsjusta_oshainspector"] = true,
        ["j_itsjusta_chance"] = true,
        ["j_itsjusta_stars"] = true,
        ["j_itsjusta_flower"] = true,
        ["j_itsjusta_rage"] = true,
        ["j_itsjusta_glitch"] = true,
        ["j_itsjusta__50mult"] = true,
        ["j_itsjusta_geometrydash"] = true,
        ["j_itsjusta_codingattempt"] = true,
        ["j_itsjusta_nothingishere"] = true,
        ["j_itsjusta_dog"] = true
    },
})


SMODS.current_mod.optional_features = function()
    return {
        cardareas = {},
        post_trigger = true 
    }
end