
SMODS.Seal {
    key = 'glitch',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            xmult0 = 1.5,
            xmult = 1.5,
            card_draw0 = 5,
            dollars0 = 9
        }
    },
    badge_colour = HEX('8A2BE2'),
    loc_txt = {
        name = 'GLITCH',
        label = 'GLITCH',
        text = {
            [1] = ''
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "button", per = 1.2, vol = 0.4 },
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 1.5
            }
        end
        if context.cardarea == G.hand and context.main_scoring then
            return {
                Xmult = 1.5
            }
        end
        if context.discard and context.other_card == card then
            if G.hand and #G.hand.cards > 0 then
                SMODS.draw_cards(5)
            end
            G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
            G.E_MANAGER:add_event(Event({
                trigger = 'before',
                delay = 0.0,
                func = function()
                    if G.GAME.last_hand_played then
                        local _planet = nil
                        for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                            if v.config.hand_type == G.GAME.last_hand_played then
                                _planet = v.key
                            end
                        end
                        if _planet then
                            local planet_card = SMODS.add_card({ key = _planet })
                        end
                        G.GAME.consumeable_buffer = 0
                    end
                    return true
                end
            }))
            return {
                message = "+"..tostring(5).." Cards Drawn",
                extra = {
                    message = localize('k_plus_planet'),
                    colour = G.C.SECONDARY_SET.Planet
                }
            }
        end
        if context.end_of_round and context.cardarea == G.hand and context.other_card == card and context.individual then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 9
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(card, 'extra', nil, nil, nil, {message = "+"..tostring(9), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end
}