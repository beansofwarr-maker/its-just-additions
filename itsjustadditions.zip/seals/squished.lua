
SMODS.Seal {
    key = 'squished',
    pos = { x = 2, y = 0 },
    badge_colour = HEX('96CEB4'),
    loc_txt = {
        name = 'Squished',
        label = 'Squished',
        text = {
            [1] = 'create your last played',
            [2] = '{C:attention}Planet card{} when discarded'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
            G.E_MANAGER:add_event(Event({
                trigger = 'before',
                delay = 0.0,
                func = function()
                    if G.GAME.last_hand_played then
                        local _planet = nil
                        for k, v in pairs(G.P_CENTER_POOLS.Planet) do
                            if v.config.hand_type == G.GAME.last_hand_played then
                                _planet = v.key
                            end
                        end
                        if _planet then
                            local planet_card = SMODS.add_card({ key = _planet })
                        end
                        G.GAME.consumeable_buffer = 0
                    end
                    return true
                end
            }))
            return {
                message = localize('k_plus_planet')
            }
        end
    end
}