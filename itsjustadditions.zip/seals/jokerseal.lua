
SMODS.Seal {
    key = 'jokerseal',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            xmult0 = 1.254373566346485
        }
    },
    badge_colour = HEX('ffb8b8'),
    loc_txt = {
        name = 'Joker Seal',
        label = 'Joker Seal',
        text = {
            [1] = 'laughs then gives you',
            [2] = '{X:red,C:white}X1.254373566346485{}',
            [3] = 'Mult'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("itsjusta_laughBOOM")
                    
                    return true
                end,
            }))
            return {
                Xmult = 1.254373566346485
            }
        end
    end
}