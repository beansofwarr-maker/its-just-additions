
SMODS.Seal {
    key = 'stoneseal',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            xmult0 = 1.1
        }
    },
    badge_colour = HEX('515152'),
    loc_txt = {
        name = 'Stone Seal',
        label = 'Stone Seal',
        text = {
            [1] = 'Gives {X:red,C:white}+10%{} of your Mult'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 1.1
            }
        end
    end
}