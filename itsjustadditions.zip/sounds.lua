SMODS.Sound{
    key="laughBOOM",
    path="laughBOOM.ogg",
    pitch=0.7,
    volume=0.6,
}