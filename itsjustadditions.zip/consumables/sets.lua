SMODS.ConsumableType {
    key = 'mystical',
    primary_colour = HEX('50e3c2'),
    secondary_colour = HEX('50e3c2'),
    collection_rows = { 4, 5 },
    shop_rate = 1,
    cards = {},
    loc_txt = {
        name = "Mystical",
        collection = "Mystical Cards",
    }
}