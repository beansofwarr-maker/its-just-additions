SMODS.Rarity {
    key = "mythical",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.001,
    badge_colour = HEX('d0021b'),
    loc_txt = {
        name = "Mythical"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "exotic",
    pools = {
        ["Joker"] = true
    },
    default_weight = 1e-9,
    badge_colour = HEX('9013fe'),
    loc_txt = {
        name = "Exotic"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}